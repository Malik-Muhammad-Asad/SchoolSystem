<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.classes-resource.pages.create-classes' => 'App\\Filament\\Resources\\ClassesResource\\Pages\\CreateClasses',
    'app.filament.resources.classes-resource.pages.edit-classes' => 'App\\Filament\\Resources\\ClassesResource\\Pages\\EditClasses',
    'app.filament.resources.classes-resource.pages.list-classes' => 'App\\Filament\\Resources\\ClassesResource\\Pages\\ListClasses',
    'app.filament.resources.classes-resource.pages.view-classes' => 'App\\Filament\\Resources\\ClassesResource\\Pages\\ViewClasses',
    'app.filament.resources.exam-resource.pages.create-exam' => 'App\\Filament\\Resources\\ExamResource\\Pages\\CreateExam',
    'app.filament.resources.exam-resource.pages.edit-exam' => 'App\\Filament\\Resources\\ExamResource\\Pages\\EditExam',
    'app.filament.resources.exam-resource.pages.list-exams' => 'App\\Filament\\Resources\\ExamResource\\Pages\\ListExams',
    'app.filament.resources.exam-resource.pages.view-exam' => 'App\\Filament\\Resources\\ExamResource\\Pages\\ViewExam',
    'app.filament.resources.exam-result-resource.pages.create-exam-result' => 'App\\Filament\\Resources\\ExamResultResource\\Pages\\CreateExamResult',
    'app.filament.resources.exam-result-resource.pages.edit-exam-result' => 'App\\Filament\\Resources\\ExamResultResource\\Pages\\EditExamResult',
    'app.filament.resources.exam-result-resource.pages.list-exam-results' => 'App\\Filament\\Resources\\ExamResultResource\\Pages\\ListExamResults',
    'app.filament.resources.exam-result-resource.pages.view-exam-results' => 'App\\Filament\\Resources\\ExamResultResource\\Pages\\ViewExamResults',
    'app.filament.resources.student-resource.pages.create-student' => 'App\\Filament\\Resources\\StudentResource\\Pages\\CreateStudent',
    'app.filament.resources.student-resource.pages.edit-student' => 'App\\Filament\\Resources\\StudentResource\\Pages\\EditStudent',
    'app.filament.resources.student-resource.pages.list-students' => 'App\\Filament\\Resources\\StudentResource\\Pages\\ListStudents',
    'app.filament.resources.student-resource.pages.view-student' => 'App\\Filament\\Resources\\StudentResource\\Pages\\ViewStudent',
    'app.filament.resources.subject-resource.pages.create-subject' => 'App\\Filament\\Resources\\SubjectResource\\Pages\\CreateSubject',
    'app.filament.resources.subject-resource.pages.edit-subject' => 'App\\Filament\\Resources\\SubjectResource\\Pages\\EditSubject',
    'app.filament.resources.subject-resource.pages.list-subjects' => 'App\\Filament\\Resources\\SubjectResource\\Pages\\ListSubjects',
    'app.filament.resources.term-resource.pages.create-term' => 'App\\Filament\\Resources\\TermResource\\Pages\\CreateTerm',
    'app.filament.resources.term-resource.pages.edit-term' => 'App\\Filament\\Resources\\TermResource\\Pages\\EditTerm',
    'app.filament.resources.term-resource.pages.list-terms' => 'App\\Filament\\Resources\\TermResource\\Pages\\ListTerms',
    'app.filament.resources.term-resource.pages.view-term' => 'App\\Filament\\Resources\\TermResource\\Pages\\ViewTerm',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'F:\\School\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'F:\\School\\app\\Filament\\Resources\\ClassesResource.php' => 'App\\Filament\\Resources\\ClassesResource',
    'F:\\School\\app\\Filament\\Resources\\ExamResource.php' => 'App\\Filament\\Resources\\ExamResource',
    'F:\\School\\app\\Filament\\Resources\\ExamResultResource.php' => 'App\\Filament\\Resources\\ExamResultResource',
    'F:\\School\\app\\Filament\\Resources\\StudentResource.php' => 'App\\Filament\\Resources\\StudentResource',
    'F:\\School\\app\\Filament\\Resources\\SubjectResource.php' => 'App\\Filament\\Resources\\SubjectResource',
    'F:\\School\\app\\Filament\\Resources\\TermResource.php' => 'App\\Filament\\Resources\\TermResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'F:\\School\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'F:\\School\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);